# Mohamed Medhat AbdelFattah — Portfolio

Personal portfolio for a Full Stack .NET Developer. Plain HTML, CSS and JavaScript, no build step, hosted on GitHub Pages.

Live site: https://mohamed090medhat199-create.github.io/portfolio/

## Structure

```
portfolio/
├── index.html              All page content (sections in page order)
├── README.md
├── robots.txt              Search engine rules + sitemap location
├── sitemap.xml
├── .nojekyll               Tells GitHub Pages to serve files as-is
└── assets/
    ├── css/
    │   └── style.css       Design tokens (colors, fonts) at the top, then components
    ├── js/
    │   └── main.js         Navbar, mobile menu, dark mode, active link, image preview
    └── images/
        ├── profile.jpg     Hero photo (square, 900x900)
        └── projects/
            ├── titanic-app.jpg
            ├── titanic-tree.jpg
            └── library-home.jpg
```

## Page order

Home, About, Education, Training, Skills, Services, Projects, Contact.

## Common edits

- **Change the photo:** replace `assets/images/profile.jpg` with a square image of the same name.
- **Add a project:** copy one `<article class="project">` block in the Projects section of `index.html`, put its screenshot in `assets/images/projects/`, and update the text, tech badges and GitHub link.
- **Add a live demo button:** inside `.project__actions`, add `<a class="btn btn--secondary btn--sm" href="DEMO_URL" target="_blank" rel="noopener noreferrer">Live Demo</a>`.
- **Change colors:** edit the variables at the top of `assets/css/style.css` (`:root` for light, `[data-theme="dark"]` for dark).

## Deploy

Upload the contents of this folder to the repository root and keep the folder layout above. If the old `script.js` and `styles.css` are still in the repo root, delete them; they are no longer used.
